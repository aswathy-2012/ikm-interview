package com.Planetary.Planetary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanetaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanetaryApplication.class, args);
	}

}
